import { Component } from '@angular/core';

@Component({
  selector: 'app-feedbacks',
  standalone: true,
  imports: [],
  templateUrl: './feedbacks.component.html',
  styleUrl: './feedbacks.component.css'
})
export class FeedbacksComponent {

}
